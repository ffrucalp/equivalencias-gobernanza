import { useState, useEffect, useRef } from "react";

// ============ UCALP PROGRAMS DATA ============
const UCALP_PROGRAMS = {
  "estrategias_comunicacionales": {
    name: "Estrategias Comunicacionales",
    professor: "Francisco Fernández Ruiz",
    hours: 64,
    year: "1°",
    units: [
      { number: 1, title: "Fundamentos de la comunicación y retórica clásica", topics: "Comunicación humana: modelos y elementos. Texto, discurso y contexto. Retórica clásica: Aristóteles y Quintiliano. Tres géneros retóricos (deliberativo, judicial, epidíctico). Cinco operaciones retóricas: inventio, dispositio, elocutio, memoria, actio. Ethos, pathos y logos. Análisis de charlas TED desde la retórica aristotélica." },
      { number: 2, title: "Lectura crítica y comprensión textual", topics: "Lectura académica: estrategias. Secuencias textuales: narrativa, descriptiva, explicativa, argumentativa, dialogal. Inferencias e hipótesis de lectura. Elementos paratextuales. Redes y mapas conceptuales. Géneros discursivos y esferas sociales de uso." },
      { number: 3, title: "Fenómenos de la textualidad y análisis del discurso", topics: "Cohesión y coherencia textual. Procedimientos lingüísticos para mantenimiento del referente. Ambigüedad, polisemia, estilo directo e indirecto. Objetividad y subjetividad en el lenguaje. Lo explícito y lo implícito. Marcadores discursivos y conectores." },
      { number: 4, title: "El texto académico: análisis y producción", topics: "Texto académico: registro, léxico, estructura. Tipos: resumen, informe, ensayo, monografía, abstract. Citas directas e indirectas, notas al pie, normas APA 7.ª ed. Argumentación académica: tesis, premisas, evidencia, conclusión." },
      { number: 5, title: "Oralidad persuasiva: del discurso clásico al formato TED", topics: "Oralidad académica y profesional. Estructura de presentación oral. Storytelling aplicado a comunicación de datos. Recursos retóricos: anáfora, metáfora, antítesis, pregunta retórica. Formato TED. Comunicación oral en entornos virtuales." }
    ]
  },
  "fundamentos_computacion": {
    name: "Fundamentos de Computación",
    professor: "Lic. Sebastián Cerezo",
    hours: 48,
    year: "1°",
    units: [
      { number: 1, title: "Arquitectura de computadoras", topics: "Historia de la computación. Componentes del hardware: CPU, memoria RAM, almacenamiento, periféricos. Modelo de Von Neumann y ciclo de instrucción. Representación de la información: sistemas numéricos binario, octal y hexadecimal. Tipos de buses y comunicación entre componentes." },
      { number: 2, title: "Sistemas operativos – conceptos y administración", topics: "Concepto y funciones del sistema operativo. Tipos: monousuario, multiusuario, tiempo real. Estructura interna: kernel, shell e interfaz de usuario. Gestión de procesos, memoria y archivos. Administración en Windows. Introducción a GNU/Linux: filosofía, distribuciones y línea de comandos." },
      { number: 3, title: "Redes de computadoras y protocolos", topics: "Conceptos fundamentales de redes: topologías y tipos. Modelo OSI y modelo TCP/IP. Protocolo IP: direccionamiento IPv4 e IPv6, máscaras de subred. Protocolos de aplicación: HTTP/HTTPS, DNS, DHCP, FTP, SSH. Dispositivos de red: routers, switches, access points." },
      { number: 4, title: "Almacenamiento y gestión de archivos", topics: "Tipos de almacenamiento: HDD, SSD, NVMe, RAID. Sistemas de archivos: FAT32, NTFS, ext4. Particionado de discos y gestión de volúmenes. Estrategias de backup y recuperación de datos." },
      { number: 5, title: "Virtualización y computación en la nube", topics: "Virtualización: completa, paravirtualización y contenedores. Hipervisores Tipo 1 y Tipo 2. VirtualBox, VMware. Docker y contenedores. Computación en la nube: modelos IaaS, PaaS y SaaS. AWS, Azure, Google Cloud. Seguridad y privacidad en entornos virtualizados." }
    ]
  },
  "intro_economia": {
    name: "Introducción a la Economía",
    professor: "Cra. Silvina Lorenzi",
    hours: 64,
    year: "1°",
    units: [
      { number: 1, title: "Introducción a la Economía", topics: "Definición de Economía y relación con datos. Fuentes de datos económicos. Microeconomía y Macroeconomía. Principio de escasez. Necesidades, Bienes y Servicios. Recursos productivos. Flujo Circular de la Renta. Costo de Oportunidad. Frontera de Posibilidades de Producción. Agentes económicos. Sistemas económicos. Historia del Pensamiento Económico: Fisiocracia, Mercantilismo, Adam Smith, David Ricardo, Marxismo, Escuela Neoclásica, Keynes." },
      { number: 2, title: "Equilibrio de Oferta y Demanda. El Mercado", topics: "Ley de Demanda. Curva de Demanda. Variables significativas. Cambios en la demanda y en la cantidad demandada. Curva de Oferta. Equilibrio de mercado. Desplazamiento de las curvas. Elasticidad precio de la demanda." },
      { number: 3, title: "La Empresa", topics: "Concepto de empresa. Producción. Combinación de recursos productivos. Función de Producción. Corto Plazo. Ley de rendimientos marginales decrecientes. Largo Plazo. Rendimientos a escala. Teoría de los costos de Corto Plazo. Clases de costos." },
      { number: 4, title: "Los Mercados", topics: "Tipos de mercado. Competencia Perfecta: supuestos, beneficio, curva de oferta. Competencia Imperfecta: Monopolio, discriminación de precios, regulaciones. Competencia Monopólica. Monopsonio. Oligopolio. Duopolio. Posición de la Iglesia." },
      { number: 5, title: "Introducción a la Macroeconomía", topics: "PIB y crecimiento económico. Inflación, desempleo y ciclos económicos. Política monetaria y política fiscal. Series de tiempo en análisis macroeconómico. Visualización e interpretación de indicadores." }
    ]
  },
  "intro_gobernanza": {
    name: "Introducción a la Gobernanza de Datos",
    professor: "Ing. Felipe Rojo Amadeo",
    hours: 64,
    year: "1°",
    units: [
      { number: 1, title: "El dato y la gobernanza de datos", topics: "Dato como activo estratégico. Jerarquía DIKW. Tipos de datos: estructurados, semiestructurados, no estructurados. Economía del dato: organizaciones data-driven. Definición y alcance de gobernanza de datos. Data Governance vs Data Management. Principios: responsabilidad, integridad, transparencia, accesibilidad. Frameworks: DAMA-DMBOK, COBIT for Data, enfoque no invasivo (Seiner). Modelos de madurez." },
      { number: 2, title: "Políticas, procesos, roles y estructuras", topics: "Políticas de datos: definición, tipología y ciclo de vida. Diseño e implementación de políticas. Toma de decisiones basada en datos. Roles: Data Owner, Data Steward, Data Custodian, Data User. Comité de Datos, CDO. Modelos: centralizado, federado, híbrido. Gestión del cambio y cultura del dato." },
      { number: 3, title: "Ciclo de vida del dato y calidad de datos", topics: "Etapas: creación/captura, almacenamiento, procesamiento, uso/análisis, archivo, eliminación. Linaje de datos: trazabilidad, impacto, auditoría. Integración de datos. Metadatos y catálogos. Gestión de datos maestros (MDM). Calidad: exactitud, completitud, consistencia, oportunidad, unicidad, validez. Métricas, KPIs y scorecards. Profiling, limpieza y monitoreo continuo." },
      { number: 4, title: "Seguridad, privacidad y marco normativo", topics: "Confidencialidad, integridad, disponibilidad. Amenazas y vulnerabilidades. Controles: clasificación de datos, acceso basado en roles, cifrado. Privacy by Design. Gestión de incidentes. Ley 25.326 de Protección de Datos Personales (Argentina). GDPR europeo. Derechos de titulares: acceso, rectificación, supresión, portabilidad." },
      { number: 5, title: "Gobernanza en entornos emergentes y ética del dato", topics: "Big Data: las 5V e implicancias para gobernanza. Cloud, data lakes y data mesh. Gobernanza de IA: responsabilidad algorítmica. Sesgos algorítmicos: identificación y mitigación. EU AI Act. Ética aplicada a datos. Prudencia y deliberación. Consentimiento, finalidad, proporcionalidad. Responsabilidad social del profesional." }
    ]
  },
  "matematicas": {
    name: "Matemáticas",
    professor: "Caterina Meteo",
    hours: 64,
    year: "1°",
    units: [
      { number: 1, title: "Lógica y teoría de conjuntos", topics: "Proposiciones y conectivos lógicos. Tablas de verdad. Negaciones. Equivalencias lógicas. Conjuntos: operaciones básicas." },
      { number: 2, title: "Funciones elementales", topics: "Funciones: operación y composición. Representación gráfica e interpretación. Dominio, imagen e inversa. Crecimiento y decrecimiento." },
      { number: 3, title: "Límites y continuidad", topics: "Noción intuitiva y formal de límite. Límites en un punto, laterales, finitos e infinitos. Propiedades y cálculos. Continuidad y tipos de discontinuidades." },
      { number: 4, title: "Derivadas", topics: "Derivada como razón de cambio. Reglas de derivación. Derivadas de funciones elementales. Derivadas de orden superior. Relación derivabilidad-continuidad. Extremos relativos y absolutos. Concavidad y puntos de inflexión. Análisis cualitativo y gráfico." },
      { number: 5, title: "Integración y ecuaciones diferenciales", topics: "Integral definida e indefinida. Regla de Barrow. Teorema Fundamental del Cálculo. Métodos básicos de integración. Integrales impropias. EDO de primer orden. Variables separables. Modelos de crecimiento y decaimiento." },
      { number: 6, title: "Sucesiones y series", topics: "Sucesiones numéricas. Límite y convergencia. Series numéricas. Criterios básicos de convergencia. Criterio de Leibnitz. Series de potencias." },
      { number: 7, title: "Álgebra lineal", topics: "Vectores y matrices. Sistemas de ecuaciones lineales. Método de Gauss. Espacios vectoriales: definición y ejemplos. Bases y dimensión." },
      { number: 8, title: "Polinomios y ecuaciones algebraicas", topics: "Polinomios: operaciones y propiedades. Raíces y factorización. Ecuaciones algebraicas. Teorema Fundamental del Álgebra." },
      { number: 9, title: "Estructuras algebraicas", topics: "Concepto de estructura algebraica. Grupos, anillos y cuerpos. Noción de módulo." },
      { number: 10, title: "Funciones de varias variables", topics: "Funciones de dos variables. Derivadas parciales. Regla de la cadena. Integrales triples, integrales de línea y de superficie. Interpretación geométrica." }
    ]
  }
};

const MODELS = [
  { id: "anthropic/claude-sonnet-4.6", label: "Claude Sonnet 4.6", icon: "🟣" },
  { id: "google/gemini-3-flash-preview", label: "Gemini 3 Flash", icon: "🔵" },
  { id: "arcee-ai/trinity-large-preview:free", label: "Trinity Large (gratis)", icon: "🟢" },
  { id: "openrouter/hunter-Alpha", label: "Hunter Alpha", icon: "🟠" },
];

const COMMON_UNIVERSITIES = [
  "Universidad Nacional de La Plata (UNLP)",
  "Universidad de Buenos Aires (UBA)",
  "Universidad Tecnológica Nacional (UTN)",
  "Universidad Nacional de Córdoba (UNC)",
  "Universidad Nacional de Rosario (UNR)",
  "Universidad del Salvador (USAL)",
  "Universidad de Ciencias Empresariales y Sociales (UCES)",
  "Otra (especificar)"
];

const COMMON_CAREERS = [
  "Ingeniería en Sistemas",
  "Ingeniería en Computación",
  "Ingeniería Industrial",
  "Ingeniería Electrónica",
  "Ingeniería Mecánica",
  "Licenciatura en Sistemas",
  "Licenciatura en Informática",
  "Contador Público",
  "Licenciatura en Administración",
  "Licenciatura en Economía",
  "Abogacía / Derecho",
  "Otra (especificar)"
];

// ============ FILE EXTRACTION ============
async function extractTextFromFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (ext === "txt") return await file.text();
  if (ext === "docx") return await extractDocx(file);
  if (ext === "pdf") return await extractPdf(file);
  throw new Error("Formato no soportado. Usá PDF, DOCX o TXT.");
}

async function extractDocx(file) {
  if (!window.mammoth) {
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js");
  }
  const buf = await file.arrayBuffer();
  const result = await window.mammoth.extractRawText({ arrayBuffer: buf });
  return result.value;
}

async function extractPdf(file) {
  if (!window.pdfjsLib) {
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js");
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
  }
  const buf = await file.arrayBuffer();
  const pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
  let text = "";
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(item => item.str).join(" ") + "\n";
  }
  return text;
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
    const s = document.createElement("script"); s.src = src;
    s.onload = resolve; s.onerror = reject;
    document.head.appendChild(s);
  });
}

// ============ PDF FROM URL ============
async function extractPdfFromUrl(url) {
  if (!window.pdfjsLib) {
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js");
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
  }
  // Fetch PDF via proxy as arraybuffer
  const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
  const resp = await fetch(proxyUrl);
  if (!resp.ok) throw new Error("No se pudo descargar el PDF.");
  const buf = await resp.arrayBuffer();
  const pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
  let text = "";
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(item => item.str).join(" ") + "\n";
  }
  return text;
}

// ============ GOOGLE SHEETS IMPORT ============
async function importFromGoogleSheets(url) {
  // Extract sheet ID from various Google Sheets URL formats
  let sheetId = null;
  const match = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
  if (match) sheetId = match[1];
  if (!sheetId) throw new Error("URL de Google Sheets no válida. Debe ser algo como https://docs.google.com/spreadsheets/d/...");
  
  // Fetch as CSV (works for public or "anyone with link" sheets)
  const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
  const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(csvUrl)}`;
  const resp = await fetch(proxyUrl);
  if (!resp.ok) throw new Error("No se pudo acceder al Sheet. Verificá que esté compartido como 'Cualquier persona con el enlace'.");
  const csv = await resp.text();
  
  // Parse CSV into rows
  const rows = csv.split("\n").map(row => {
    const cells = [];
    let current = "", inQuotes = false;
    for (const ch of row) {
      if (ch === '"') { inQuotes = !inQuotes; }
      else if (ch === ',' && !inQuotes) { cells.push(current.trim()); current = ""; }
      else { current += ch; }
    }
    cells.push(current.trim());
    return cells;
  }).filter(r => r.some(c => c.length > 0));
  
  return rows;
}

// ============ HTML TABLE PARSER (for pasting UNLP-style HTML) ============
function parseHtmlTable(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const subjects = [];
  // Pattern 1: UNLP style - links to catedras in <td> elements
  doc.querySelectorAll("tr").forEach(row => {
    const tds = row.querySelectorAll("td");
    if (tds.length >= 2) {
      // Skip separator rows
      if (row.querySelector(".separador_semestre")) return;
      // Get subject name from second td (might be in an <a> tag)
      const nameCell = tds[1];
      const link = nameCell.querySelector("a");
      const name = (link ? link.textContent : nameCell.textContent).trim();
      // Skip empty, AFC, and header-like entries
      if (name && name.length > 2 && !/^(actividades de formación|afc\s)/i.test(name)
        && !/^(cód|asignatura|materia|optativa$)/i.test(name)) {
        // Get code from first td
        const codeCell = tds[0];
        const code = codeCell.textContent.trim();
        if (!subjects.find(s => s.name === name)) {
          subjects.push({ name, details: code || "" });
        }
      }
    }
  });
  // Pattern 2: generic table
  if (subjects.length === 0) {
    doc.querySelectorAll("td, li").forEach(el => {
      const t = el.textContent.trim();
      if (t.length > 3 && t.length < 120 && /[a-záéíóúñ]{3,}/i.test(t)
        && !/^\d+$/.test(t) && !subjects.find(s => s.name === t)) {
        subjects.push({ name: t, details: "" });
      }
    });
  }
  return subjects;
}

// ============ AI-ASSISTED EXTRACTION ============
async function aiExtractSubjects(rawText, apiKey, model) {
  const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}`, "HTTP-Referer": "https://ucalp-equivalencias.pages.dev", "X-Title": "UCALP Equivalencias" },
    body: JSON.stringify({
      model: model,
      messages: [
        { role: "system", content: "Sos un asistente que extrae listas de materias/asignaturas de planes de estudio universitarios. Respondé SOLO con un JSON array de strings con los nombres de las materias, sin texto adicional, sin backticks. Ejemplo: [\"Matemática I\", \"Física I\", \"Introducción a la Economía\"]" },
        { role: "user", content: `Extraé la lista completa de materias/asignaturas del siguiente texto de un plan de estudios universitario. Devolvé SOLO el JSON array:\n\n${rawText.substring(0, 6000)}` }
      ],
      temperature: 0.1,
      max_tokens: 3000
    })
  });
  if (!resp.ok) { const e = await resp.json().catch(() => ({})); throw new Error(e?.error?.message || `Error ${resp.status}`); }
  const data = await resp.json();
  const text = data.choices?.[0]?.message?.content || "";
  const clean = text.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
  try {
    const arr = JSON.parse(clean);
    if (Array.isArray(arr)) return arr;
  } catch {}
  const match2 = clean.match(/\[[\s\S]*\]/);
  if (match2) return JSON.parse(match2[0]);
  throw new Error("No se pudo parsear la respuesta de la IA.");
}

// ============ WEB SCRAPER (improved) ============
// Pre-loaded plans for UNLP (most common origin) - JS-rendered pages can't be scraped
const UNLP_PRELOADED = {
  "industrial": { pdf: "https://www1.ing.unlp.edu.ar/sitio/grado/2018/industrial-2018.pdf", subjects: [
    "Matemática para Ingeniería","Matemática A","Química para Ingeniería","Introducción a la Ingeniería Industrial","Matemática B","Física I","Representación Gráfica","Matemática C","Física II","Termodinámica y Recursos Energéticos","Introducción a la Programación y Análisis Numérico","Estructuras","Materiales","Probabilidades y Estadística","Macroeconomía y Políticas Económicas Argentinas","Mecánica y Mecanismos","Electrotecnia y Electrónica","Microeconomía","Producción I","Procesos de Fabricación","Mecánica de los Fluidos","Higiene y Seguridad en el Trabajo","Industrias","Administración General y Sistemas Administrativos","Producción II","Máquinas e Instalaciones Eléctricas","Administración Financiera","Comercialización","Fundamentos de Ingeniería Ambiental","Ingeniería Legal y Ejercicio Profesional","Administración de Personal","Dirección General","Formulación y Evaluación de Proyectos","Automatismos y Controles Industriales","Instalaciones Industriales","Producción III","Práctica Profesional Supervisada","Inglés"]},
  "computacion": { pdf: "https://www1.ing.unlp.edu.ar/sitio/grado/vigentes/computacion.pdf", subjects: [
    "Matemática A","Programación I","Sistemas de Representación","Matemática B","Programación II","Química","Física I","Programación III","Taller de Lenguaje I","Conceptos de Arquitectura de Computadoras","Matemática C","Física II","Matemática D","Electrotecnia y Electrónica","Conceptos de Bases de Datos","Introducción al Diseño Lógico","Introducción al Procesamiento de Señales","Taller de Arquitectura","Ingeniería de Software","Redes de Datos I","Concurrencia y Paralelismo","Instrumentación y Control","Bases de Datos","Circuitos Digitales y Microcontroladores","Economía y Emprendedorismo","Redes de Datos II","Sistemas de Tiempo Real","Taller de Proyecto I","Sistemas Distribuidos y Paralelos","Aspectos Legales de Ingeniería Informática","Taller de Proyecto II","Seminario de Redacción de Textos Profesionales","Práctica Profesional Supervisada"]},
  "mecanica": { pdf: "https://www1.ing.unlp.edu.ar/sitio/grado/2018/Planilla-1-Mecanica-2018.pdf", subjects: [
    "Matemática para Ingeniería","Introducción a la Ingeniería Mecánica y Electromecánica","Matemática A","Química General","Matemática B","Informática","Dibujo para Ingeniería y Sistemas de Representación","Física I","Matemática C","Estabilidad","Ciencia de los Materiales","Probabilidad y Estadística","Tecnología Mecánica","Física II","Termodinámica","Máquinas Térmicas","Electrotecnia y Máquinas Eléctricas","Mecanismos y Elementos de Máquinas","Mecánica de los Fluidos","Resistencia de Materiales","Transferencia de Calor y Masa","Diseño Mecánico","Instalaciones Industriales","Proyecto Final"]},
  "electronica": { pdf: "https://www1.ing.unlp.edu.ar/sitio/grado/vigentes/electronica.pdf", subjects: [
    "Matemática A","Programación","Sistemas de Representación","Matemática B","Informática","Química","Física I","Matemática C","Electrotecnia","Física II","Matemática D","Técnica Digital","Teoría de los Circuitos I","Electrónica I","Teoría de los Circuitos II","Electrónica II","Medidas Electrónicas I","Máquinas Eléctricas","Electrónica III","Sistemas de Control","Comunicaciones","Tecnología Electrónica","Sistemas Digitales","Proyecto Final"]},
  "civil": { pdf: "https://www1.ing.unlp.edu.ar/sitio/grado/vigentes/civil.pdf", subjects: [
    "Matemática para Ingeniería","Representación Gráfica","Introducción a la Ingeniería Civil e Hidráulica","Matemática A","Matemática B","Física I","Química","Estructuras I","Matemática C","Física II","Estructuras II","Materiales I","Probabilidades y Estadística","Hidráulica General I","Estructuras III","Hidráulica General II","Materiales II","Introducción a la Programación y Análisis Numérico","Estructuras IV","Topografía","Hidrología","Gestión Ambiental","Economía para Ingenieros","Geotecnia I","Hormigón Armado I","Construcciones Metálicas y de Madera","Transportes","Planeamiento Regional y Urbano","Hormigón Armado II","Edificios I","Geotecnia II","Obras Hidráulicas","Ingeniería Legal","Edificios II","Caminos I","Ingeniería Sanitaria","Higiene y Seguridad en el Trabajo","Evaluación de Proyectos y Organización de Obras","Proyecto Final","Práctica Profesional Supervisada","Complementos de Estructuras","Complementos de Transportes","Competencias Actitudinales, Sociales y Políticas","Inglés"]},
};
const UNLP_ECON_SUBJECTS = {
  "contador": ["Contabilidad Superior I","Introducción a la Economía y Estructura Económica Argentina","Administración I","Matemática I (Análisis Matemático)","Derecho I (Constitucional y Administrativo)","Introducción a las Ciencias Sociales","Microeconomía I","Contabilidad Superior II","Macroeconomía I","Matemática II (Álgebra)","Derecho II (Privado)","Estadística para los Negocios","Contabilidad III","Administración II","Finanzas Públicas I","Historia Económica y Social Argentina","Contabilidad IV","Régimen Tributario I","Contabilidad V (Costos)","Matemática para Decisiones Empresarias","Auditoría","Régimen Tributario II","Contabilidad VI","Contabilidad VII","Dirección General","Seminario"],
  "administracion": ["Contabilidad Superior I","Introducción a la Economía y Estructura Económica Argentina","Administración I","Matemática I (Análisis Matemático)","Derecho I (Constitucional y Administrativo)","Introducción a las Ciencias Sociales","Microeconomía I","Contabilidad Superior II","Macroeconomía I","Matemática II (Álgebra)","Derecho II (Privado)","Estadística para los Negocios","Administración II","Administración de la Producción","Administración de Personal","Administración Financiera","Comercialización","Sistemas de Información","Dirección General","Formulación y Evaluación de Proyectos"],
};

async function scrapeStudyPlan(url) {
  let finalUrl = url;
  let redirected = false;

  // Smart redirect: check for preloaded UNLP plans
  if (url.includes("ing.unlp.edu.ar") || url.includes("www1.ing.unlp.edu.ar")) {
    const slug = url.toLowerCase();
    for (const [key, data] of Object.entries(UNLP_PRELOADED)) {
      if (slug.includes(key) || slug.includes(key.replace(/a$/, ""))) {
        return {
          subjects: data.subjects.map(s => ({ name: s, details: "" })),
          rawText: `Plan precargado: UNLP Ingeniería - ${key} - ${data.subjects.length} materias`,
          pdfLinks: [{ url: data.pdf, text: "📄 PDF oficial del plan de estudios" }],
          redirectedUrl: null,
          preloaded: true
        };
      }
    }
  }
  // UNLP Económicas
  if (url.includes("econo.unlp.edu.ar")) {
    for (const [key, subjects] of Object.entries(UNLP_ECON_SUBJECTS)) {
      if (url.toLowerCase().includes(key)) {
        return {
          subjects: subjects.map(s => ({ name: s, details: "" })),
          rawText: `Plan precargado: UNLP Económicas - ${subjects.length} materias`,
          pdfLinks: [],
          redirectedUrl: null,
          preloaded: true
        };
      }
    }
  }

  // Fetch via CORS proxy
  let html = null;
  // Strategy 1: allorigins /get (returns JSON with contents field)
  try {
    const resp = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(finalUrl)}`, { signal: AbortSignal.timeout(15000) });
    if (resp.ok) {
      const data = await resp.json();
      if (data.contents) html = data.contents;
    }
  } catch {}
  // Strategy 2: corsproxy
  if (!html) {
    try {
      const resp = await fetch(`https://corsproxy.io/?${encodeURIComponent(finalUrl)}`, { signal: AbortSignal.timeout(15000) });
      if (resp.ok) html = await resp.text();
    } catch {}
  }
  // Strategy 3: api.codetabs
  if (!html) {
    try {
      const resp = await fetch(`https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(finalUrl)}`, { signal: AbortSignal.timeout(15000) });
      if (resp.ok) html = await resp.text();
    } catch {}
  }
  if (!html) throw new Error("No se pudo acceder. Probá con otra URL o copiá el contenido manualmente.");

  // Detect if response is actually a PDF — parse it
  if (html.substring(0, 10).includes("%PDF")) {
    try {
      const pdfText = await extractPdfFromUrl(finalUrl);
      return {
        subjects: [],
        rawText: pdfText,
        pdfLinks: [{ url: finalUrl, text: "PDF del plan de estudios" }],
        redirectedUrl: redirected ? finalUrl : null,
        isPdfParsed: true
      };
    } catch {
      return {
        subjects: [],
        rawText: "(No se pudo parsear el PDF. Descargalo y subilo en Analizar > Subir archivo.)",
        pdfLinks: [{ url: finalUrl, text: "Descargar PDF" }],
        redirectedUrl: redirected ? finalUrl : null
      };
    }
  }

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  doc.querySelectorAll("script, style").forEach(el => el.remove());

  let subjects = [];
  let pdfLinks = [];

  // 1. Tables (most study plans)
  doc.querySelectorAll("table").forEach(table => {
    table.querySelectorAll("tr").forEach(row => {
      const cells = Array.from(row.querySelectorAll("td, th")).map(c => c.textContent.trim());
      if (cells.length >= 2) {
        for (const cell of cells) {
          const clean = cell.replace(/\s+/g, " ").trim();
          if (clean.length > 4 && clean.length < 120
            && !/^\d+$/.test(clean) && !/^[A-Z]\d{3,}$/.test(clean)
            && !/^(cód|codigo|correlat|semestre|cuatri|año|hs|hora|plan|carga|tipo|hes|het|hfp|asignatura|materia|1er|2do|3er)/i.test(clean)
            && /[a-záéíóúñ]{3,}/i.test(clean)
            && !subjects.find(s => s.name === clean)) {
            subjects.push({ name: clean, details: cells.join(" | ") });
            break;
          }
        }
      }
    });
  });

  // 2. Links to cátedras (UNLP old site pattern)
  if (subjects.length === 0) {
    doc.querySelectorAll("a").forEach(a => {
      const text = a.textContent.trim();
      const href = a.getAttribute("href") || "";
      if ((href.includes("catedra") || href.includes("analitico") || href.includes("asignatura"))
        && text.length > 3 && text.length < 100 && /[a-záéíóúñ]{2,}/i.test(text)
        && !subjects.find(s => s.name === text)) {
        subjects.push({ name: text, details: href });
      }
    });
  }

  // 3. Lists / paragraphs
  if (subjects.length === 0) {
    doc.querySelectorAll("li, dd, p").forEach(el => {
      const t = el.textContent.trim().replace(/\s+/g, " ");
      if (t.length > 5 && t.length < 120 && /^[A-ZÁÉÍÓÚÑ]/.test(t)
        && !/^(home|inicio|contacto|buscar|ver más|leer|ir a|facebook|instagram|twitter)/i.test(t)
        && !subjects.find(s => s.name === t)) {
        subjects.push({ name: t, details: "" });
      }
    });
  }

  // 4. Detect PDF links
  doc.querySelectorAll("a").forEach(a => {
    const href = a.getAttribute("href") || "";
    const text = a.textContent.trim();
    if (href.match(/\.pdf/i) || href.includes("plan.php")) {
      let fullUrl = href;
      if (href.startsWith("/")) {
        try { fullUrl = new URL(href, finalUrl).href; } catch { fullUrl = href; }
      } else if (!href.startsWith("http")) {
        try { fullUrl = new URL(href, finalUrl).href; } catch { fullUrl = href; }
      }
      if (!pdfLinks.find(p => p.url === fullUrl)) {
        pdfLinks.push({ url: fullUrl, text: text || "PDF" });
      }
    }
  });

  const mainContent = doc.querySelector("main, .content, #content, article") || doc.body;
  const navEls = mainContent.querySelectorAll("nav, .menu, .sidebar, ul.nav");
  navEls.forEach(el => el.remove());
  const rawText = mainContent.textContent.replace(/\s+/g, " ").trim().substring(0, 10000);

  return { subjects, rawText, pdfLinks, redirectedUrl: redirected ? finalUrl : null };
}

function buildPrompt(ucalpSubject, ucalpUnits, originSubject, originProgram, originUniversity, originCareer) {
  return `Sos un experto académico en análisis de equivalencias universitarias en Argentina. Tu tarea es comparar rigurosamente el programa de una materia de ORIGEN con el programa de una materia DESTINO de la Licenciatura en Gobernanza de Datos (UCALP).

## MATERIA DESTINO (UCALP - Lic. en Gobernanza de Datos)
**Materia:** ${ucalpSubject}
**Unidades:**
${ucalpUnits.map(u => `- Unidad ${u.number}: ${u.title}\n  Contenidos: ${u.topics}`).join("\n")}

## MATERIA DE ORIGEN
**Universidad:** ${originUniversity}
**Carrera:** ${originCareer}
**Materia:** ${originSubject}
**Programa/Contenidos:**
${originProgram}

## INSTRUCCIONES DE ANÁLISIS
Analizá unidad por unidad de la materia DESTINO y determiná qué porcentaje de cobertura tiene la materia de ORIGEN sobre cada una. Sé riguroso: no basta con que los temas sean vagamente similares, los contenidos deben ser sustancialmente equivalentes.

## CRITERIOS DE CLASIFICACIÓN
- **EQUIVALENCIA TOTAL**: La materia de origen cubre al menos el 80% de los contenidos de TODAS las unidades de la materia destino.
- **EQUIVALENCIA PARCIAL**: La materia de origen cubre sustancialmente (≥70%) ALGUNAS unidades pero no todas. Indicar exactamente qué unidades se reconocen y cuáles debe rendir el alumno en un examen complementario.
- **SIN EQUIVALENCIA**: La materia de origen cubre menos del 50% de los contenidos globales o los enfoques son fundamentalmente distintos.

## FORMATO DE RESPUESTA (responder SOLO en este formato JSON exacto, sin texto adicional ni backticks):
{
  "clasificacion": "TOTAL" | "PARCIAL" | "SIN_EQUIVALENCIA",
  "porcentaje_cobertura_global": <número 0-100>,
  "analisis_por_unidad": [
    {
      "unidad": <número>,
      "titulo": "<título>",
      "cobertura": <número 0-100>,
      "coincidencias": "<temas que coinciden>",
      "faltantes": "<temas que faltan o difieren>"
    }
  ],
  "unidades_reconocidas": [<números de unidades reconocidas>],
  "unidades_a_rendir": [<números de unidades que debe rendir>],
  "justificacion": "<explicación clara y fundamentada de la decisión>",
  "recomendacion": "<recomendación para el director de carrera>",
  "observaciones": "<notas adicionales relevantes>"
}`;
}

function loadData(key, fallback) {
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : fallback; } catch { return fallback; }
}
function saveData(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { console.error(e); }
}

// ============ COLORS ============
const C = {
  red: "#B71C1C",
  redLight: "#E53935",
  redSoft: "#FFEBEE",
  redBorder: "#FFCDD2",
  redAccent: "#C62828",
  redMuted: "#EF9A9A",
  bg: "#FAFAFA",
  surface: "#FFFFFF",
  surfaceAlt: "#FFF8F8",
  border: "#E0E0E0",
  borderLight: "#F5F5F5",
  text: "#212121",
  textSecondary: "#757575",
  textMuted: "#9E9E9E",
  green: "#2E7D32",
  greenSoft: "#E8F5E9",
  greenBorder: "#C8E6C9",
  amber: "#F57F17",
  amberSoft: "#FFF8E1",
  amberBorder: "#FFECB3",
  dangerSoft: "#FFEBEE",
  dangerBorder: "#FFCDD2",
  blue: "#1565C0",
  blueSoft: "#E3F2FD",
  blueBorder: "#BBDEFB",
};

export default function EquivalenciasApp() {
  const [tab, setTab] = useState("dashboard");
  const [apiKey, setApiKey] = useState("");
  const [selectedModel, setSelectedModel] = useState(MODELS[0].id);
  const [analyses, setAnalyses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState(null);
  const [expandedAnalysis, setExpandedAnalysis] = useState(null);
  const [showApiKeyModal, setShowApiKeyModal] = useState(false);
  const [originUniversity, setOriginUniversity] = useState(COMMON_UNIVERSITIES[0]);
  const [customUniversity, setCustomUniversity] = useState("");
  const [originCareer, setOriginCareer] = useState(COMMON_CAREERS[0]);
  const [customCareer, setCustomCareer] = useState("");
  const [originSubject, setOriginSubject] = useState("");
  const [originProgram, setOriginProgram] = useState("");
  const [targetSubject, setTargetSubject] = useState(Object.keys(UCALP_PROGRAMS)[0]);
  const [result, setResult] = useState(null);
  const [inputMode, setInputMode] = useState("text"); // "text" | "file" | "scrape"
  const [fileProcessing, setFileProcessing] = useState(false);
  const [fileName, setFileName] = useState("");
  const [scrapeUrl, setScrapeUrl] = useState("");
  const [scraping, setScraping] = useState(false);
  const [scrapedPlan, setScrapedPlan] = useState(null);
  const [savedPlans, setSavedPlans] = useState([]);
  const [sheetsUrl, setSheetsUrl] = useState("");
  const [sheetsData, setSheetsData] = useState(null);
  const [sheetsLoading, setSheetsLoading] = useState(false);
  const [aiExtracting, setAiExtracting] = useState(false);
  const [htmlPaste, setHtmlPaste] = useState("");
  const [htmlParsed, setHtmlParsed] = useState(null);
  const resultRef = useRef(null);

  useEffect(() => {
    const saved = loadData("eq-analyses-v2", []);
    const key = loadData("eq-apikey-v2", "");
    const model = loadData("eq-model-v2", MODELS[0].id);
    const plans = loadData("eq-plans-v2", []);
    setAnalyses(saved); setApiKey(key); setSelectedModel(model); setSavedPlans(plans); setLoading(false);
    // Favicon y título
    document.title = "Equivalencias · UCALP Gobernanza de Datos";
    let link = document.querySelector("link[rel~='icon']");
    if (!link) { link = document.createElement("link"); link.rel = "icon"; link.type = "image/png"; document.head.appendChild(link); }
    link.href = "https://www.ucalp.edu.ar/wp-content/uploads/2016/08/apple-touch-icon.png";
    let link2 = document.querySelector("link[rel='apple-touch-icon']");
    if (!link2) { link2 = document.createElement("link"); link2.rel = "apple-touch-icon"; document.head.appendChild(link2); }
    link2.href = "https://www.ucalp.edu.ar/wp-content/uploads/2016/08/apple-touch-icon.png";
  }, []);

  const saveApiKey = (k) => { setApiKey(k); saveData("eq-apikey-v2", k); };
  const saveModel = (m) => { setSelectedModel(m); saveData("eq-model-v2", m); };

  const runAnalysis = async () => {
    if (!apiKey) { setShowApiKeyModal(true); return; }
    const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity;
    const car = originCareer.includes("Otra") ? customCareer : originCareer;
    if (!originSubject.trim() || !originProgram.trim()) { setError("Completá el nombre y programa de la materia de origen."); return; }
    setAnalyzing(true); setError(null); setResult(null);
    const prog = UCALP_PROGRAMS[targetSubject];
    const prompt = buildPrompt(prog.name, prog.units, originSubject, originProgram, uni, car);
    try {
      const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}`, "HTTP-Referer": "https://ucalp-equivalencias.pages.dev", "X-Title": "UCALP Equivalencias" },
        body: JSON.stringify({ model: selectedModel, messages: [{ role: "system", content: "Sos un experto académico en análisis de equivalencias universitarias argentinas. Respondé SOLAMENTE con JSON válido, sin backticks ni texto adicional." }, { role: "user", content: prompt }], temperature: 0.2, max_tokens: 4000 })
      });
      if (!resp.ok) { const errData = await resp.json().catch(() => ({})); throw new Error(errData?.error?.message || `Error ${resp.status}`); }
      const data = await resp.json();
      const text = data.choices?.[0]?.message?.content || "";
      const clean = text.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
      let parsed;
      try { parsed = JSON.parse(clean); } catch { const match = clean.match(/\{[\s\S]*\}/); if (match) parsed = JSON.parse(match[0]); else throw new Error("No se pudo parsear la respuesta. Intentá con otro modelo."); }
      const record = { id: Date.now().toString(), date: new Date().toISOString(), originUniversity: uni, originCareer: car, originSubject, targetSubject: prog.name, targetSubjectKey: targetSubject, model: selectedModel, result: parsed, originProgram: originProgram.substring(0, 2000) };
      setResult(record);
      const updated = [record, ...analyses]; setAnalyses(updated); saveData("eq-analyses-v2", updated);
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth" }), 200);
    } catch (e) { setError(e.message); } finally { setAnalyzing(false); }
  };

  const deleteAnalysis = (id) => { const u = analyses.filter(a => a.id !== id); setAnalyses(u); saveData("eq-analyses-v2", u); };
  const clearAll = () => { if (confirm("¿Eliminar TODAS las equivalencias guardadas?")) { setAnalyses([]); saveData("eq-analyses-v2", []); } };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    setFileProcessing(true); setError(null); setFileName(file.name);
    try {
      const text = await extractTextFromFile(file);
      setOriginProgram(text);
      setInputMode("text"); // Switch to text view to show extracted content
    } catch (err) { setError(err.message); } finally { setFileProcessing(false); }
  };

  const handleScrape = async () => {
    if (!scrapeUrl.trim()) return;
    setScraping(true); setError(null); setScrapedPlan(null);
    try {
      const plan = await scrapeStudyPlan(scrapeUrl);
      setScrapedPlan(plan);
    } catch (err) { setError("Error scrapeando: " + err.message); } finally { setScraping(false); }
  };

  const savePlan = (university, career, subjects, url) => {
    const plan = { id: Date.now().toString(), date: new Date().toISOString(), university, career, url, subjects };
    const updated = [plan, ...savedPlans];
    setSavedPlans(updated); saveData("eq-plans-v2", updated);
    return plan;
  };

  const deletePlan = (id) => { const u = savedPlans.filter(p => p.id !== id); setSavedPlans(u); saveData("eq-plans-v2", u); };

  const handleSheetsImport = async () => {
    if (!sheetsUrl.trim()) return;
    setSheetsLoading(true); setError(null); setSheetsData(null);
    try {
      const rows = await importFromGoogleSheets(sheetsUrl);
      setSheetsData(rows);
    } catch (e) { setError(e.message); } finally { setSheetsLoading(false); }
  };

  const handleAiExtract = async (rawText) => {
    if (!apiKey) { setShowApiKeyModal(true); return; }
    setAiExtracting(true); setError(null);
    try {
      const subjects = await aiExtractSubjects(rawText, apiKey, selectedModel);
      const parsed = subjects.map(s => ({ name: s, details: "" }));
      // Update whichever context triggered this
      if (scrapedPlan) {
        setScrapedPlan({ ...scrapedPlan, subjects: parsed, aiParsed: true });
      }
      if (htmlPaste.trim()) {
        setHtmlParsed(parsed);
      }
    } catch (e) { setError("IA: " + e.message); } finally { setAiExtracting(false); }
  };

  const exportCSV = () => {
    if (!analyses.length) return;
    const rows = [["Fecha","Universidad","Carrera","Materia Origen","Materia UCALP","Clasificación","% Cobertura","Unidades reconocidas","Unidades a rendir","Modelo IA"]];
    analyses.forEach(a => rows.push([new Date(a.date).toLocaleDateString("es-AR"), a.originUniversity, a.originCareer, a.originSubject, a.targetSubject, a.result.clasificacion, a.result.porcentaje_cobertura_global+"%", (a.result.unidades_reconocidas||[]).join("; "), (a.result.unidades_a_rendir||[]).join("; "), a.model]));
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF"+csv], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `equivalencias_ucalp_${new Date().toISOString().slice(0,10)}.csv`; a.click();
  };

  const Badge = ({ clasificacion }) => {
    const m = { TOTAL: { bg: C.green, label: "Equivalencia Total" }, PARCIAL: { bg: C.amber, label: "Equivalencia Parcial" }, SIN_EQUIVALENCIA: { bg: C.redAccent, label: "Sin Equivalencia" } };
    const s = m[clasificacion] || { bg: C.textMuted, label: clasificacion };
    return <span style={{ display: "inline-block", padding: "4px 14px", borderRadius: 20, background: s.bg, color: "#fff", fontSize: 11, fontWeight: 700, letterSpacing: "0.6px", textTransform: "uppercase" }}>{s.label}</span>;
  };

  const CoverageCircle = ({ pct, size = 48 }) => {
    const color = pct >= 70 ? C.green : pct >= 40 ? C.amber : C.redAccent;
    return (
      <div style={{ width: size, height: size, borderRadius: "50%", background: `conic-gradient(${color} ${pct*3.6}deg, ${C.borderLight} 0deg)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: size - 8, height: size - 8, borderRadius: "50%", background: C.surface, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size > 48 ? 15 : 12, fontWeight: 700, color }}>{pct}%</div>
      </div>
    );
  };

  const stats = { total: analyses.filter(a => a.result.clasificacion === "TOTAL").length, parcial: analyses.filter(a => a.result.clasificacion === "PARCIAL").length, sin: analyses.filter(a => a.result.clasificacion === "SIN_EQUIVALENCIA").length, universities: [...new Set(analyses.map(a => a.originUniversity))].length };

  if (loading) return (
    <div style={{ height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: C.bg, fontFamily: "'Outfit', sans-serif" }}>
      <div style={{ textAlign: "center", color: C.textSecondary }}><div style={{ fontSize: 36, marginBottom: 12 }}>⚙️</div>Cargando...</div>
    </div>
  );

  const tabData = [
    { id: "dashboard", icon: "📊", label: "Panel" },
    { id: "analyze", icon: "🔍", label: "Analizar" },
    { id: "plans", icon: "🌐", label: "Planes" },
    { id: "programs", icon: "📋", label: "Programas" },
    { id: "settings", icon: "⚙️", label: "Configuración" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
      <style>{`
        @keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
        details summary::-webkit-details-marker { display: none; }
        details summary { list-style: none; }
        ::selection { background: ${C.redMuted}; color: ${C.red}; }
      `}</style>

      {/* ─── HEADER ─── */}
      <header style={{ background: C.red, color: "#fff", boxShadow: "0 2px 12px rgba(183,28,28,0.25)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 70 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{ width: 46, height: 46, borderRadius: "50%", background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 1px 4px rgba(0,0,0,0.15)" }}>
                <img src="https://www.ucalp.edu.ar/wp-content/uploads/2016/08/apple-touch-icon.png" alt="UCALP" style={{ height: 36, borderRadius: "50%" }} />
              </div>
              <div>
                <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, fontWeight: 700, lineHeight: 1.15, letterSpacing: "-0.3px" }}>Equivalencias UCALP</div>
                <div style={{ fontSize: 11, opacity: 0.85, letterSpacing: "0.6px", textTransform: "uppercase", fontFamily: "'DM Sans', sans-serif", marginTop: 2 }}>Lic. en Gobernanza de Datos · Fac. de Cs. Exactas e Ingeniería</div>
              </div>
            </div>
            <nav style={{ display: "flex", gap: 2 }}>
              {tabData.map(t => (
                <button key={t.id} onClick={() => setTab(t.id)} style={{
                  padding: "8px 14px", borderRadius: 6, border: "none", cursor: "pointer",
                  background: tab === t.id ? "rgba(255,255,255,0.2)" : "transparent",
                  color: "#fff", fontSize: 13, fontWeight: tab === t.id ? 700 : 400,
                  transition: "all 0.15s", opacity: tab === t.id ? 1 : 0.8,
                  fontFamily: "'DM Sans', sans-serif"
                }}>{t.icon} {t.label}</button>
              ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Accent line */}
      <div style={{ height: 3, background: `linear-gradient(90deg, ${C.red}, ${C.redLight}, ${C.redMuted}, ${C.redLight}, ${C.red})` }} />

      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 24px 80px" }}>

        {/* ═══════ DASHBOARD ═══════ */}
        {tab === "dashboard" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 14, marginBottom: 32 }}>
              {[
                { label: "Análisis realizados", value: analyses.length, color: C.red, bg: C.redSoft, border: C.redBorder },
                { label: "Equiv. Totales", value: stats.total, color: C.green, bg: C.greenSoft, border: C.greenBorder },
                { label: "Equiv. Parciales", value: stats.parcial, color: C.amber, bg: C.amberSoft, border: C.amberBorder },
                { label: "Sin Equivalencia", value: stats.sin, color: C.redAccent, bg: C.dangerSoft, border: C.dangerBorder },
                { label: "Universidades", value: stats.universities, color: C.red, bg: C.redSoft, border: C.redBorder },
              ].map((s, i) => (
                <div key={i} style={{ background: s.bg, borderRadius: 12, padding: "18px 16px", border: `1px solid ${s.border}` }}>
                  <div style={{ fontSize: 30, fontWeight: 700, color: s.color, fontFamily: "'Outfit', sans-serif" }}>{s.value}</div>
                  <div style={{ fontSize: 12, color: C.textSecondary, marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 22, color: C.text, margin: 0, fontWeight: 700 }}>Historial de equivalencias</h2>
              {analyses.length > 0 && (
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={exportCSV} style={btnOutline}>📥 Exportar CSV</button>
                  <button onClick={clearAll} style={{ ...btnOutline, borderColor: C.redBorder, color: C.redAccent }}>🗑 Limpiar</button>
                </div>
              )}
            </div>

            {analyses.length === 0 ? (
              <div style={{ background: C.surface, borderRadius: 16, padding: 56, textAlign: "center", border: `2px dashed ${C.redBorder}` }}>
                <div style={{ fontSize: 48, marginBottom: 14 }}>📝</div>
                <div style={{ fontSize: 18, color: C.text, marginBottom: 6, fontFamily: "'Outfit', sans-serif", fontWeight: 600 }}>No hay análisis guardados</div>
                <div style={{ fontSize: 14, color: C.textSecondary, marginBottom: 24 }}>Iniciá tu primer análisis de equivalencias.</div>
                <button onClick={() => setTab("analyze")} style={btnPrimary}>🔍 Iniciar análisis</button>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {analyses.map(a => (
                  <div key={a.id} style={{ background: C.surface, borderRadius: 12, border: `1px solid ${C.border}`, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
                    <div onClick={() => setExpandedAnalysis(expandedAnalysis === a.id ? null : a.id)}
                      style={{ padding: "14px 18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14 }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                          <Badge clasificacion={a.result.clasificacion} />
                          <span style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{a.originSubject}</span>
                          <span style={{ fontSize: 12, color: C.textMuted }}>→</span>
                          <span style={{ fontSize: 13, color: C.textSecondary }}>{a.targetSubject}</span>
                        </div>
                        <div style={{ fontSize: 12, color: C.textMuted, marginTop: 5 }}>{a.originUniversity} · {a.originCareer} · {new Date(a.date).toLocaleDateString("es-AR")}</div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <CoverageCircle pct={a.result.porcentaje_cobertura_global} />
                        <span style={{ fontSize: 16, color: C.textMuted, transform: expandedAnalysis === a.id ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>▾</span>
                      </div>
                    </div>

                    {expandedAnalysis === a.id && (
                      <div style={{ padding: "0 18px 18px", borderTop: `1px solid ${C.borderLight}`, animation: "fadeIn 0.2s ease" }}>
                        <div style={{ paddingTop: 14, display: "flex", flexDirection: "column", gap: 8 }}>
                          <div style={{ fontSize: 13, fontWeight: 600, color: C.textSecondary, marginBottom: 4 }}>Análisis por unidad</div>
                          {(a.result.analisis_por_unidad || []).map((u, i) => (
                            <UnitDetail key={i} u={u} recognized={(a.result.unidades_reconocidas||[]).includes(u.unidad)} />
                          ))}
                          {a.result.unidades_a_rendir?.length > 0 && <AlertBox color="amber" icon="📝" title="Unidades a rendir" text={(a.result.unidades_a_rendir||[]).map(n => { const u2 = (a.result.analisis_por_unidad||[]).find(x => x.unidad === n); return `Unidad ${n}${u2 ? `: ${u2.titulo}` : ""}`; }).join(" · ")} />}
                          <InfoBox color={C.red} title="Justificación" text={a.result.justificacion} />
                          {a.result.recomendacion && <InfoBox color={C.amber} title="Recomendación" text={a.result.recomendacion} />}
                          <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <span style={{ fontSize: 11, color: C.textMuted }}>Modelo: {a.model}</span>
                            <button onClick={(e) => { e.stopPropagation(); deleteAnalysis(a.id); }} style={{ ...btnOutline, borderColor: C.redBorder, color: C.redAccent, padding: "5px 12px", fontSize: 11 }}>Eliminar</button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ═══════ ANALYZE ═══════ */}
        {tab === "analyze" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, color: C.text, marginBottom: 4, fontWeight: 700 }}>Nuevo análisis de equivalencia</h2>
            <p style={{ color: C.textSecondary, fontSize: 14, marginBottom: 24 }}>Ingresá los datos de la materia de origen y seleccioná la materia UCALP contra la cual comparar.</p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 22 }}>
              {/* Left: Origin */}
              <div style={cardStyle}>
                <SectionTitle icon="🏛" color={C.redAccent} label="Materia de origen" />
                <Label>Universidad de origen</Label>
                <select value={originUniversity} onChange={e => setOriginUniversity(e.target.value)} style={selectStyle}>{COMMON_UNIVERSITIES.map(u => <option key={u} value={u}>{u}</option>)}</select>
                {originUniversity.includes("Otra") && <input placeholder="Nombre de la universidad..." value={customUniversity} onChange={e => setCustomUniversity(e.target.value)} style={{ ...inputStyle, marginTop: 6 }} />}

                <Label>Carrera de origen</Label>
                <select value={originCareer} onChange={e => setOriginCareer(e.target.value)} style={selectStyle}>{COMMON_CAREERS.map(c => <option key={c} value={c}>{c}</option>)}</select>
                {originCareer.includes("Otra") && <input placeholder="Nombre de la carrera..." value={customCareer} onChange={e => setCustomCareer(e.target.value)} style={{ ...inputStyle, marginTop: 6 }} />}

                <Label>Nombre de la materia</Label>
                <input placeholder="Ej: Análisis Matemático I" value={originSubject} onChange={e => setOriginSubject(e.target.value)} style={inputStyle} />

                <Label>Programa / Contenidos</Label>
                <div style={{ display: "flex", gap: 4, marginBottom: 10 }}>
                  {[{ id: "text", icon: "📝", label: "Pegar texto" }, { id: "file", icon: "📄", label: "Subir archivo" }, { id: "scrape", icon: "🌐", label: "Desde URL" }].map(m => (
                    <button key={m.id} onClick={() => setInputMode(m.id)} style={{
                      flex: 1, padding: "8px 6px", borderRadius: 6, border: `1.5px solid ${inputMode === m.id ? C.red : C.border}`,
                      background: inputMode === m.id ? C.redSoft : C.surface, color: inputMode === m.id ? C.redAccent : C.textSecondary,
                      cursor: "pointer", fontSize: 11, fontWeight: inputMode === m.id ? 600 : 400, transition: "all 0.15s"
                    }}>{m.icon} {m.label}</button>
                  ))}
                </div>

                {inputMode === "text" && (
                  <textarea placeholder={"Pegá acá el programa completo de la materia de origen.\n\nPodés copiar y pegar desde un PDF, Word, o página web.\n\nCuanto más detallado, más preciso el análisis."} value={originProgram} onChange={e => setOriginProgram(e.target.value)} style={{ ...inputStyle, minHeight: 180, resize: "vertical", lineHeight: 1.55 }} />
                )}

                {inputMode === "file" && (
                  <div style={{ padding: 20, borderRadius: 8, border: `2px dashed ${C.redBorder}`, background: C.redSoft, textAlign: "center" }}>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>📄</div>
                    <div style={{ fontSize: 13, color: C.textSecondary, marginBottom: 12 }}>Subí el programa en PDF, DOCX o TXT</div>
                    <input type="file" accept=".pdf,.docx,.doc,.txt" onChange={handleFileUpload} style={{ fontSize: 13 }} />
                    {fileProcessing && <div style={{ marginTop: 10, fontSize: 13, color: C.red, fontWeight: 600 }}>⚙️ Extrayendo texto de {fileName}...</div>}
                    {fileName && !fileProcessing && originProgram && (
                      <div style={{ marginTop: 10, fontSize: 12, color: C.green, fontWeight: 500 }}>✓ Texto extraído de {fileName} ({originProgram.length} caracteres). Podés revisarlo en la pestaña "Pegar texto".</div>
                    )}
                  </div>
                )}

                {inputMode === "scrape" && (
                  <div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <input placeholder="https://www.econo.unlp.edu.ar/..." value={scrapeUrl} onChange={e => setScrapeUrl(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                      <button onClick={handleScrape} disabled={scraping} style={{ ...btnPrimary, padding: "10px 16px", fontSize: 12, opacity: scraping ? 0.7 : 1, whiteSpace: "nowrap" }}>
                        {scraping ? "⚙️..." : "🌐 Buscar"}
                      </button>
                    </div>
                    <div style={{ fontSize: 11, color: C.textMuted, marginTop: 6 }}>URLs de UNLP Ingeniería y Económicas están precargadas. Para otras, pegá la URL del plan.</div>
                    {scrapedPlan && (
                      <div style={{ marginTop: 12, padding: 12, borderRadius: 8, background: scrapedPlan.preloaded ? C.greenSoft : C.blueSoft, border: `1px solid ${scrapedPlan.preloaded ? C.greenBorder : C.blueBorder}`, maxHeight: 250, overflow: "auto" }}>
                        {scrapedPlan.preloaded && <div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginBottom: 6 }}>✅ Plan precargado</div>}
                        {scrapedPlan.redirectedUrl && (
                          <div style={{ fontSize: 11, color: C.green, marginBottom: 6 }}>🔄 Redirigido a: {scrapedPlan.redirectedUrl}</div>
                        )}
                        <div style={{ fontSize: 12, fontWeight: 600, color: C.blue, marginBottom: 6 }}>
                          {scrapedPlan.subjects.length > 0 ? `${scrapedPlan.subjects.length} materias encontradas` : "Contenido extraído"} ({scrapedPlan.rawText.length} caracteres)
                        </div>
                        {scrapedPlan.subjects.length > 0 && (
                          <div style={{ marginBottom: 8 }}>
                            {scrapedPlan.subjects.slice(0, 8).map((s, i) => (
                              <div key={i} style={{ fontSize: 11, color: C.text, padding: "2px 0" }}>• {s.name}</div>
                            ))}
                            {scrapedPlan.subjects.length > 8 && <div style={{ fontSize: 11, color: C.textMuted }}>... y {scrapedPlan.subjects.length - 8} más</div>}
                          </div>
                        )}
                        {scrapedPlan.pdfLinks?.length > 0 && (
                          <div style={{ marginBottom: 8, fontSize: 11, color: C.amber }}>📄 {scrapedPlan.pdfLinks.length} PDF(s) encontrados en la página</div>
                        )}
                        <button onClick={() => { setOriginProgram(scrapedPlan.rawText); setInputMode("text"); }} style={{ ...btnOutline, fontSize: 11, padding: "6px 12px", borderColor: C.blueBorder, color: C.blue }}>
                          📋 Usar como contenido
                        </button>
                        <button onClick={() => { const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity; const car = originCareer.includes("Otra") ? customCareer : originCareer; savePlan(uni, car, scrapedPlan.subjects, scrapeUrl); }} style={{ ...btnOutline, fontSize: 11, padding: "6px 12px", marginLeft: 6, borderColor: C.greenBorder, color: C.green }}>
                          💾 Guardar plan
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {originProgram && <div style={{ marginTop: 6, fontSize: 11, color: C.green }}>✓ {originProgram.length} caracteres cargados</div>}
              </div>

              {/* Right */}
              <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                <div style={cardStyle}>
                  <SectionTitle icon="🎯" color={C.red} label="Materia UCALP destino" />
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    {Object.entries(UCALP_PROGRAMS).map(([key, prog]) => (
                      <button key={key} onClick={() => setTargetSubject(key)} style={{
                        padding: "12px 14px", borderRadius: 8, cursor: "pointer", textAlign: "left", transition: "all 0.15s", fontSize: 13, border: `1.5px solid`,
                        borderColor: targetSubject === key ? C.red : C.border,
                        background: targetSubject === key ? C.redSoft : C.surface,
                        color: targetSubject === key ? C.redAccent : C.text,
                      }}>
                        <div style={{ fontWeight: 600 }}>{prog.name}</div>
                        <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{prog.units.length} unidades · {prog.hours} hs · Prof. {prog.professor}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div style={cardStyle}>
                  <SectionTitle icon="🤖" color={C.textSecondary} label="Modelo de IA" />
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                    {MODELS.map(m => (
                      <button key={m.id} onClick={() => saveModel(m.id)} style={{
                        padding: "10px 10px", borderRadius: 7, cursor: "pointer", textAlign: "left", fontSize: 12, transition: "all 0.15s", border: `1.5px solid`,
                        borderColor: selectedModel === m.id ? C.red : C.border,
                        background: selectedModel === m.id ? C.redSoft : C.surface,
                        color: selectedModel === m.id ? C.redAccent : C.textSecondary,
                        fontWeight: selectedModel === m.id ? 600 : 400
                      }}>{m.icon} {m.label}</button>
                    ))}
                  </div>
                </div>

                <button onClick={runAnalysis} disabled={analyzing} style={{
                  ...btnPrimary, padding: "15px 28px", fontSize: 15, opacity: analyzing ? 0.7 : 1, cursor: analyzing ? "wait" : "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 8
                }}>
                  {analyzing ? <><span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>⚙️</span> Analizando con IA...</> : "🔍 Ejecutar análisis de equivalencia"}
                </button>
              </div>
            </div>

            {error && <div style={{ marginTop: 18, padding: 14, borderRadius: 10, background: C.dangerSoft, border: `1px solid ${C.dangerBorder}`, color: C.redAccent, fontSize: 13 }}>⚠️ {error}</div>}

            {result && (
              <div ref={resultRef} style={{ ...cardStyle, marginTop: 26, animation: "fadeIn 0.3s ease" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
                  <div>
                    <h3 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 20, color: C.text, margin: 0, fontWeight: 700 }}>Resultado del análisis</h3>
                    <div style={{ fontSize: 13, color: C.textMuted, marginTop: 3 }}>{result.originSubject} ({result.originUniversity}) → {result.targetSubject}</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <Badge clasificacion={result.result.clasificacion} />
                    <CoverageCircle pct={result.result.porcentaje_cobertura_global} size={54} />
                  </div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {(result.result.analisis_por_unidad || []).map((u, i) => (
                    <UnitDetail key={i} u={u} recognized={(result.result.unidades_reconocidas||[]).includes(u.unidad)} />
                  ))}
                </div>

                {result.result.unidades_a_rendir?.length > 0 && <div style={{ marginTop: 14 }}><AlertBox color="amber" icon="📝" title="Unidades a rendir en examen complementario" text={(result.result.unidades_a_rendir||[]).map(n => { const u2 = (result.result.analisis_por_unidad||[]).find(x => x.unidad === n); return `Unidad ${n}${u2 ? `: ${u2.titulo}` : ""}`; }).join(" · ")} /></div>}
                <div style={{ marginTop: 14 }}><InfoBox color={C.red} title="Justificación" text={result.result.justificacion} /></div>
                {result.result.recomendacion && <div style={{ marginTop: 8 }}><InfoBox color={C.amber} title="Recomendación" text={result.result.recomendacion} /></div>}
                {result.result.observaciones && <div style={{ marginTop: 8 }}><InfoBox color={C.textMuted} title="Observaciones" text={result.result.observaciones} /></div>}
              </div>
            )}
          </div>
        )}

        {/* ═══════ PLANES ═══════ */}
        {tab === "plans" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, color: C.text, marginBottom: 4, fontWeight: 700 }}>Planes de estudio scrapeados</h2>
            <p style={{ color: C.textSecondary, fontSize: 14, marginBottom: 20 }}>Cargá planes desde URLs, PDFs, HTML de tablas o Google Sheets. Los de UNLP Ingeniería y Económicas están precargados.</p>

            <div style={cardStyle}>
              <SectionTitle icon="🌐" color={C.blue} label="Scrapear plan de estudios" />
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
                <div>
                  <Label>Universidad</Label>
                  <select value={originUniversity} onChange={e => setOriginUniversity(e.target.value)} style={selectStyle}>{COMMON_UNIVERSITIES.map(u => <option key={u} value={u}>{u}</option>)}</select>
                  {originUniversity.includes("Otra") && <input placeholder="Nombre..." value={customUniversity} onChange={e => setCustomUniversity(e.target.value)} style={{ ...inputStyle, marginTop: 6 }} />}
                </div>
                <div>
                  <Label>Carrera</Label>
                  <select value={originCareer} onChange={e => setOriginCareer(e.target.value)} style={selectStyle}>{COMMON_CAREERS.map(c => <option key={c} value={c}>{c}</option>)}</select>
                  {originCareer.includes("Otra") && <input placeholder="Nombre..." value={customCareer} onChange={e => setCustomCareer(e.target.value)} style={{ ...inputStyle, marginTop: 6 }} />}
                </div>
              </div>
              <Label>URL del plan de estudios</Label>
              <div style={{ display: "flex", gap: 8 }}>
                <input placeholder="https://www.econo.unlp.edu.ar/contador_publico/plan_de_estudios..." value={scrapeUrl} onChange={e => setScrapeUrl(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                <button onClick={handleScrape} disabled={scraping} style={{ ...btnPrimary, padding: "10px 20px", fontSize: 13, opacity: scraping ? 0.7 : 1, whiteSpace: "nowrap" }}>
                  {scraping ? "⚙️ Scrapeando..." : "🌐 Extraer plan"}
                </button>
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 6, lineHeight: 1.5 }}>
                Planes de UNLP Ingeniería (Industrial, Computación, Mecánica, Electrónica, Civil) y Económicas (Contador, Administración) están precargados. Para otras carreras: pegá la URL, subí un PDF, pegá el HTML de la tabla, o importá desde Google Sheets.
              </div>

              {scrapedPlan && (
                <div style={{ marginTop: 16, padding: 16, borderRadius: 10, background: scrapedPlan.preloaded ? C.greenSoft : C.blueSoft, border: `1px solid ${scrapedPlan.preloaded ? C.greenBorder : C.blueBorder}` }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: scrapedPlan.preloaded ? C.green : C.blue, marginBottom: 10 }}>
                    {scrapedPlan.preloaded ? "✅ Plan precargado (base de datos UCALP)" : "Resultado del scraping"}
                  </div>
                  {scrapedPlan.redirectedUrl && (
                    <div style={{ fontSize: 12, color: C.green, marginBottom: 10, padding: "6px 10px", borderRadius: 6, background: C.greenSoft, border: `1px solid ${C.greenBorder}` }}>
                      🔄 URL redirigida a: <span style={{ fontFamily: "monospace", fontSize: 11 }}>{scrapedPlan.redirectedUrl}</span>
                    </div>
                  )}
                  {scrapedPlan.subjects.length > 0 ? (
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 8 }}>{scrapedPlan.subjects.length} materias encontradas:</div>
                      <div style={{ maxHeight: 300, overflow: "auto", display: "flex", flexDirection: "column", gap: 4 }}>
                        {scrapedPlan.subjects.map((s, i) => (
                          <div key={i} style={{ padding: "8px 12px", borderRadius: 6, background: C.surface, border: `1px solid ${C.borderLight}`, fontSize: 13 }}>
                            <span style={{ fontWeight: 600, color: C.text }}>{s.name}</span>
                          </div>
                        ))}
                      </div>
                      <button onClick={() => {
                        const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity;
                        const car = originCareer.includes("Otra") ? customCareer : originCareer;
                        savePlan(uni, car, scrapedPlan.subjects, scrapeUrl);
                        setScrapedPlan(null); setScrapeUrl("");
                      }} style={{ ...btnPrimary, marginTop: 12, padding: "10px 20px", fontSize: 13 }}>
                        💾 Guardar este plan
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div style={{ fontSize: 13, color: C.textSecondary, marginBottom: 8 }}>No se encontraron materias en tabla.</div>
                    </div>
                  )}
                  {/* PDF links found */}
                  {scrapedPlan.pdfLinks && scrapedPlan.pdfLinks.length > 0 && (
                    <div style={{ marginTop: 12, padding: 12, borderRadius: 8, background: C.amberSoft, border: `1px solid ${C.amberBorder}` }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: C.amber, marginBottom: 6 }}>📄 PDFs encontrados en la página:</div>
                      {scrapedPlan.pdfLinks.map((pdf, i) => (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                          <a href={pdf.url} target="_blank" rel="noopener" style={{ fontSize: 12, color: C.blue, textDecoration: "underline" }}>
                            {pdf.text || pdf.url}
                          </a>
                          <button onClick={() => setScrapeUrl(pdf.url)} style={{ ...btnOutline, fontSize: 10, padding: "3px 8px" }}>Scrapear esta</button>
                        </div>
                      ))}
                    </div>
                  )}
                  {/* Raw text fallback */}
                  {scrapedPlan.subjects.length === 0 && scrapedPlan.rawText && (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Texto extraído ({scrapedPlan.rawText.length} caracteres):</div>
                      <div style={{ maxHeight: 150, overflow: "auto", padding: 8, borderRadius: 6, background: C.surface, fontSize: 11, color: C.textSecondary, lineHeight: 1.5, border: `1px solid ${C.borderLight}` }}>
                        {scrapedPlan.rawText.substring(0, 2000)}
                      </div>
                      <button onClick={() => {
                        const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity;
                        const car = originCareer.includes("Otra") ? customCareer : originCareer;
                        savePlan(uni, car, [{ name: "Plan completo (texto)", details: scrapedPlan.rawText.substring(0, 5000) }], scrapeUrl);
                        setScrapedPlan(null); setScrapeUrl("");
                      }} style={{ ...btnPrimary, marginTop: 10, padding: "8px 16px", fontSize: 12 }}>
                        💾 Guardar como texto
                      </button>
                    </div>
                  )}
                  {/* AI extraction button — show when we have text but few subjects */}
                  {scrapedPlan.rawText && scrapedPlan.rawText.length > 100 && !scrapedPlan.preloaded && !scrapedPlan.aiParsed && (
                    <div style={{ marginTop: 12, padding: 12, borderRadius: 8, background: "rgba(139,92,246,0.06)", border: "1px solid rgba(139,92,246,0.15)" }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: "#7C3AED", marginBottom: 6 }}>🤖 Extracción con IA</div>
                      <div style={{ fontSize: 12, color: C.textSecondary, marginBottom: 8 }}>
                        {scrapedPlan.subjects.length === 0
                          ? "No se encontraron materias automáticamente. Usá la IA para extraer las materias del texto."
                          : "Podés mejorar la extracción usando IA para limpiar y estructurar mejor la lista."}
                      </div>
                      <button onClick={() => handleAiExtract(scrapedPlan.rawText)} disabled={aiExtracting}
                        style={{ ...btnOutline, fontSize: 12, padding: "8px 16px", borderColor: "rgba(139,92,246,0.3)", color: "#7C3AED", opacity: aiExtracting ? 0.6 : 1 }}>
                        {aiExtracting ? "⚙️ Procesando con IA..." : "🤖 Extraer materias con IA"}
                      </button>
                    </div>
                  )}
                  {scrapedPlan.aiParsed && (
                    <div style={{ marginTop: 8, fontSize: 11, color: "#7C3AED", fontWeight: 600 }}>✨ Lista procesada con IA ({selectedModel.split("/").pop()})</div>
                  )}
                </div>
              )}
            </div>

            {/* HTML Paste */}
            <div style={{ ...cardStyle, marginTop: 20 }}>
              <SectionTitle icon="📋" color={C.redAccent} label="Pegar HTML de tabla (UNLP y otras)" />
              <p style={{ fontSize: 12, color: C.textSecondary, marginBottom: 10, lineHeight: 1.5 }}>
                Abrí la página de la carrera → click derecho sobre la tabla de materias → <b>Inspeccionar</b> → copiá el HTML de la tabla (<code>&lt;table&gt;...&lt;/table&gt;</code>) y pegalo acá.
              </p>
              <textarea placeholder='Pegá el HTML de la tabla acá...\n\nEjemplo: <table class="carreras">...' value={htmlPaste} onChange={e => setHtmlPaste(e.target.value)} style={{ ...inputStyle, minHeight: 100, resize: "vertical", fontFamily: "monospace", fontSize: 11, lineHeight: 1.4 }} />
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <button onClick={() => {
                  const subjects = parseHtmlTable(htmlPaste);
                  if (subjects.length === 0) { setError("No se encontraron materias en el HTML. Verificá que copiaste la tabla correctamente."); return; }
                  setHtmlParsed(subjects);
                }} disabled={!htmlPaste.trim()} style={{ ...btnPrimary, padding: "8px 16px", fontSize: 12, opacity: htmlPaste.trim() ? 1 : 0.5 }}>
                  🔍 Parsear HTML
                </button>
                {htmlPaste.trim() && apiKey && (
                  <button onClick={() => handleAiExtract(htmlPaste)} disabled={aiExtracting} style={{ ...btnOutline, fontSize: 12, padding: "8px 16px", borderColor: "rgba(139,92,246,0.3)", color: "#7C3AED" }}>
                    {aiExtracting ? "⚙️..." : "🤖 Extraer con IA"}
                  </button>
                )}
              </div>
              {htmlParsed && htmlParsed.length > 0 && (
                <div style={{ marginTop: 14, padding: 14, borderRadius: 8, background: C.greenSoft, border: `1px solid ${C.greenBorder}` }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.green, marginBottom: 8 }}>{htmlParsed.length} materias extraídas:</div>
                  <div style={{ maxHeight: 200, overflow: "auto", display: "flex", flexDirection: "column", gap: 3 }}>
                    {htmlParsed.map((s, i) => (
                      <div key={i} style={{ padding: "5px 10px", borderRadius: 5, background: C.surface, border: `1px solid ${C.borderLight}`, fontSize: 12 }}>
                        {s.details && <span style={{ color: C.textMuted, marginRight: 6, fontFamily: "monospace", fontSize: 10 }}>{s.details}</span>}
                        <span style={{ fontWeight: 500, color: C.text }}>{s.name}</span>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => {
                    const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity;
                    const car = originCareer.includes("Otra") ? customCareer : originCareer;
                    savePlan(uni, car, htmlParsed, "");
                    setHtmlParsed(null); setHtmlPaste("");
                  }} style={{ ...btnPrimary, marginTop: 10, padding: "8px 16px", fontSize: 12 }}>
                    💾 Guardar plan
                  </button>
                </div>
              )}
            </div>

            {/* Google Sheets Import */}
            <div style={{ ...cardStyle, marginTop: 20 }}>
              <SectionTitle icon="📊" color={C.green} label="Importar desde Google Sheets" />
              <p style={{ fontSize: 12, color: C.textSecondary, marginBottom: 12, lineHeight: 1.5 }}>
                Si tenés los planes de estudio en una planilla de Google Sheets, compartila como "Cualquier persona con el enlace" y pegá la URL acá.
              </p>
              <div style={{ display: "flex", gap: 8 }}>
                <input placeholder="https://docs.google.com/spreadsheets/d/..." value={sheetsUrl} onChange={e => setSheetsUrl(e.target.value)} style={{ ...inputStyle, flex: 1, fontSize: 12 }} />
                <button onClick={handleSheetsImport} disabled={sheetsLoading} style={{ ...btnPrimary, padding: "10px 16px", fontSize: 12, whiteSpace: "nowrap", background: C.green, opacity: sheetsLoading ? 0.6 : 1 }}>
                  {sheetsLoading ? "⚙️..." : "📊 Importar"}
                </button>
              </div>
              {sheetsData && (
                <div style={{ marginTop: 14, padding: 14, borderRadius: 8, background: C.greenSoft, border: `1px solid ${C.greenBorder}` }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.green, marginBottom: 8 }}>{sheetsData.length} filas importadas</div>
                  <div style={{ maxHeight: 250, overflow: "auto" }}>
                    <table style={{ width: "100%", fontSize: 11, borderCollapse: "collapse" }}>
                      <tbody>
                        {sheetsData.slice(0, 30).map((row, i) => (
                          <tr key={i} style={{ background: i === 0 ? C.greenSoft : i % 2 === 0 ? C.bg : C.surface }}>
                            {row.map((cell, j) => (
                              <td key={j} style={{ padding: "4px 8px", borderBottom: `1px solid ${C.borderLight}`, color: i === 0 ? C.green : C.text, fontWeight: i === 0 ? 600 : 400 }}>
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {sheetsData.length > 30 && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 6 }}>... y {sheetsData.length - 30} filas más</div>}
                  </div>
                  <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
                    <button onClick={() => {
                      // Extract subject names from first column (skip header)
                      const subjects = sheetsData.slice(1).map(r => r[0]).filter(s => s && s.length > 2);
                      const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity;
                      const car = originCareer.includes("Otra") ? customCareer : originCareer;
                      savePlan(uni, car, subjects.map(s => ({ name: s, details: "" })), sheetsUrl);
                      setSheetsData(null); setSheetsUrl("");
                    }} style={{ ...btnPrimary, padding: "8px 16px", fontSize: 12, background: C.green }}>
                      💾 Guardar materias (1era columna)
                    </button>
                    {apiKey && (
                      <button onClick={async () => {
                        setAiExtracting(true); setError(null);
                        try {
                          const text = sheetsData.map(r => r.join(" | ")).join("\n");
                          const subjects = await aiExtractSubjects(text, apiKey, selectedModel);
                          const uni = originUniversity.includes("Otra") ? customUniversity : originUniversity;
                          const car = originCareer.includes("Otra") ? customCareer : originCareer;
                          savePlan(uni, car, subjects.map(s => ({ name: s, details: "" })), sheetsUrl);
                          setSheetsData(null); setSheetsUrl("");
                        } catch (e) { setError("IA: " + e.message); } finally { setAiExtracting(false); }
                      }} disabled={aiExtracting} style={{ ...btnOutline, fontSize: 12, padding: "8px 16px", borderColor: "rgba(139,92,246,0.3)", color: "#7C3AED" }}>
                        {aiExtracting ? "⚙️..." : "🤖 Extraer con IA"}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Saved Plans */}
            {savedPlans.length > 0 && (
              <div style={{ marginTop: 24 }}>
                <h3 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 18, color: C.text, marginBottom: 14, fontWeight: 700 }}>Planes guardados ({savedPlans.length})</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {savedPlans.map(plan => (
                    <details key={plan.id} style={{ background: C.surface, borderRadius: 12, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                      <summary style={{ padding: "14px 18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 14, fontWeight: 600, color: C.text, listStyle: "none" }}>
                        <div>
                          <div style={{ color: C.blue }}>{plan.university} — {plan.career}</div>
                          <div style={{ fontSize: 12, color: C.textMuted, fontWeight: 400, marginTop: 2 }}>
                            {plan.subjects.length} materias · {new Date(plan.date).toLocaleDateString("es-AR")}
                          </div>
                        </div>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <button onClick={(e) => { e.preventDefault(); deletePlan(plan.id); }} style={{ ...btnOutline, fontSize: 11, padding: "4px 10px", borderColor: C.redBorder, color: C.redAccent }}>🗑</button>
                          <span style={{ fontSize: 12, color: C.textMuted }}>▾</span>
                        </div>
                      </summary>
                      <div style={{ padding: "0 18px 18px" }}>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                          {plan.subjects.map((s, i) => (
                            <div key={i} style={{ padding: "6px 12px", borderRadius: 6, background: C.bg, border: `1px solid ${C.borderLight}`, fontSize: 12, color: C.text }}>{s.name}</div>
                          ))}
                        </div>
                        {plan.url && <div style={{ marginTop: 10, fontSize: 11, color: C.textMuted }}>Fuente: <a href={plan.url} target="_blank" rel="noopener" style={{ color: C.blue }}>{plan.url}</a></div>}
                      </div>
                    </details>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ═══════ PROGRAMS ═══════ */}
        {tab === "programs" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, color: C.text, marginBottom: 4, fontWeight: 700 }}>Programas UCALP precargados</h2>
            <p style={{ color: C.textSecondary, fontSize: 14, marginBottom: 22 }}>Materias del primer cuatrimestre — Lic. en Gobernanza de Datos (Plan 2025).</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {Object.entries(UCALP_PROGRAMS).map(([key, prog]) => (
                <details key={key} style={{ background: C.surface, borderRadius: 12, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                  <summary style={{ padding: "16px 18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 15, fontWeight: 600, color: C.text }}>
                    <div>
                      <div style={{ color: C.redAccent }}>{prog.name}</div>
                      <div style={{ fontSize: 12, color: C.textMuted, fontWeight: 400, marginTop: 3 }}>Prof. {prog.professor} · {prog.hours} hs · {prog.units.length} unidades</div>
                    </div>
                    <span style={{ fontSize: 11, color: C.textMuted, fontWeight: 400 }}>▾ ver</span>
                  </summary>
                  <div style={{ padding: "0 18px 18px" }}>
                    {prog.units.map(u => (
                      <div key={u.number} style={{ padding: 12, borderRadius: 8, background: C.bg, border: `1px solid ${C.borderLight}`, marginBottom: 6 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: C.red, marginBottom: 4 }}>Unidad {u.number}: {u.title}</div>
                        <div style={{ fontSize: 12, color: C.textSecondary, lineHeight: 1.5 }}>{u.topics}</div>
                      </div>
                    ))}
                  </div>
                </details>
              ))}
            </div>
          </div>
        )}

        {/* ═══════ SETTINGS ═══════ */}
        {tab === "settings" && (
          <div style={{ maxWidth: 560, animation: "fadeIn 0.3s ease" }}>
            <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 24, color: C.text, marginBottom: 22, fontWeight: 700 }}>Configuración</h2>

            <div style={{ ...cardStyle, marginBottom: 18 }}>
              <SectionTitle icon="🔑" color={C.redAccent} label="API Key de OpenRouter" />
              <p style={{ fontSize: 13, color: C.textSecondary, marginBottom: 14, lineHeight: 1.5 }}>Necesitás una API key de <a href="https://openrouter.ai/keys" target="_blank" rel="noopener" style={{ color: C.red, fontWeight: 600, textDecoration: "none" }}>openrouter.ai/keys</a> para ejecutar los análisis.</p>
              <input type="password" placeholder="sk-or-v1-..." value={apiKey} onChange={e => saveApiKey(e.target.value)} style={{ ...inputStyle, fontFamily: "monospace" }} />
              {apiKey && <div style={{ marginTop: 6, fontSize: 12, color: C.green, fontWeight: 500 }}>✓ Configurada ({apiKey.substring(0, 14)}...)</div>}
            </div>

            <div style={{ ...cardStyle, marginBottom: 18 }}>
              <SectionTitle icon="🤖" color={C.textSecondary} label="Modelo por defecto" />
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {MODELS.map(m => (
                  <button key={m.id} onClick={() => saveModel(m.id)} style={{
                    padding: "12px 14px", borderRadius: 8, cursor: "pointer", textAlign: "left", fontSize: 13, transition: "all 0.15s", border: `1.5px solid`,
                    borderColor: selectedModel === m.id ? C.red : C.border,
                    background: selectedModel === m.id ? C.redSoft : C.surface,
                    color: selectedModel === m.id ? C.redAccent : C.textSecondary,
                  }}>
                    <span style={{ marginRight: 6 }}>{m.icon}</span>
                    <span style={{ fontWeight: 600 }}>{m.label}</span>
                    <span style={{ marginLeft: 8, fontSize: 11, color: C.textMuted }}>{m.id}</span>
                  </button>
                ))}
              </div>
            </div>

            <div style={cardStyle}>
              <SectionTitle icon="📊" color={C.textSecondary} label="Datos almacenados" />
              <div style={{ fontSize: 13, color: C.textSecondary, marginBottom: 12 }}>{analyses.length} análisis · {stats.universities} universidades</div>
              {analyses.length > 0 && (
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={exportCSV} style={btnOutline}>📥 Exportar CSV</button>
                  <button onClick={clearAll} style={{ ...btnOutline, borderColor: C.redBorder, color: C.redAccent }}>🗑 Eliminar todo</button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* API Key Modal */}
      {showApiKeyModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.35)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }} onClick={() => setShowApiKeyModal(false)}>
          <div onClick={e => e.stopPropagation()} style={{ background: C.surface, borderRadius: 16, padding: 28, border: `1px solid ${C.border}`, maxWidth: 420, width: "90%", boxShadow: "0 20px 50px rgba(0,0,0,0.15)" }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 10 }}>🔑 Configurá tu API Key</h3>
            <p style={{ fontSize: 13, color: C.textSecondary, marginBottom: 18, lineHeight: 1.5 }}>Para ejecutar análisis necesitás una API Key de <a href="https://openrouter.ai/keys" target="_blank" rel="noopener" style={{ color: C.red, fontWeight: 600, textDecoration: "none" }}>openrouter.ai/keys</a></p>
            <input type="password" placeholder="sk-or-v1-..." value={apiKey} onChange={e => saveApiKey(e.target.value)} style={{ ...inputStyle, fontFamily: "monospace", marginBottom: 16 }} autoFocus />
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button onClick={() => setShowApiKeyModal(false)} style={btnOutline}>Cancelar</button>
              <button onClick={() => { if (apiKey) setShowApiKeyModal(false); }} style={{ ...btnPrimary, opacity: apiKey ? 1 : 0.5 }}>Confirmar</button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer style={{ position: "fixed", bottom: 0, left: 0, right: 0, height: 36, background: C.surface, borderTop: `1px solid ${C.borderLight}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: C.textMuted }}>
        Universidad Católica de La Plata · Fac. de Ciencias Exactas e Ingeniería · Lic. en Gobernanza de Datos · Dir. Francisco Fernández Ruiz
      </footer>
    </div>
  );
}

// ─── SMALL COMPONENTS ───
function SectionTitle({ icon, color, label }) {
  return (
    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#212121", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ background: color + "18", padding: "4px 7px", borderRadius: 6, fontSize: 13 }}>{icon}</span>
      {label}
    </h3>
  );
}

function Label({ children }) {
  return <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#757575", marginBottom: 5, marginTop: 14, letterSpacing: "0.2px" }}>{children}</label>;
}

function UnitDetail({ u, recognized }) {
  const pctColor = u.cobertura >= 70 ? C.green : u.cobertura >= 40 ? C.amber : C.redAccent;
  return (
    <div style={{
      padding: 13, borderRadius: 8, background: recognized ? C.greenSoft : C.bg,
      border: `1px solid ${recognized ? C.greenBorder : C.borderLight}`,
      borderLeft: `4px solid ${recognized ? C.green : pctColor}`
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: "#212121" }}>U{u.unidad}: {u.titulo}</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {recognized ? <span style={{ fontSize: 11, color: C.green, fontWeight: 700 }}>✓ RECONOCIDA</span> : <span style={{ fontSize: 11, color: C.redAccent, fontWeight: 700 }}>✗ DEBE RENDIR</span>}
          <span style={{ fontSize: 12, fontWeight: 700, padding: "2px 10px", borderRadius: 10, background: pctColor + "18", color: pctColor }}>{u.cobertura}%</span>
        </div>
      </div>
      {u.coincidencias && <div style={{ fontSize: 12, color: "#616161", marginBottom: 3 }}><span style={{ color: C.green }}>✓</span> {u.coincidencias}</div>}
      {u.faltantes && <div style={{ fontSize: 12, color: "#616161" }}><span style={{ color: C.redAccent }}>✗</span> {u.faltantes}</div>}
    </div>
  );
}

function AlertBox({ color, icon, title, text }) {
  const colors = { amber: { bg: C.amberSoft, border: C.amberBorder, text: C.amber }, red: { bg: C.dangerSoft, border: C.dangerBorder, text: C.redAccent } };
  const c = colors[color] || colors.amber;
  return (
    <div style={{ padding: 12, borderRadius: 8, background: c.bg, border: `1px solid ${c.border}` }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: c.text, marginBottom: 3 }}>{icon} {title}</div>
      <div style={{ fontSize: 13, color: "#424242", lineHeight: 1.5 }}>{text}</div>
    </div>
  );
}

function InfoBox({ color, title, text }) {
  return (
    <div style={{ padding: 13, borderRadius: 8, background: color + "08", border: `1px solid ${color}22` }}>
      <div style={{ fontSize: 12, fontWeight: 600, color, marginBottom: 4 }}>📋 {title}</div>
      <div style={{ fontSize: 13, color: "#424242", lineHeight: 1.55 }}>{text}</div>
    </div>
  );
}

// ─── STYLES ───
const cardStyle = { background: "#FFFFFF", borderRadius: 14, padding: 22, border: "1px solid #E0E0E0", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" };
const inputStyle = { width: "100%", padding: "11px 13px", borderRadius: 7, border: "1px solid #E0E0E0", background: "#FAFAFA", color: "#212121", fontSize: 13, outline: "none", boxSizing: "border-box", fontFamily: "'DM Sans', system-ui, sans-serif", transition: "border-color 0.15s" };
const selectStyle = { ...inputStyle, cursor: "pointer", appearance: "auto" };
const btnPrimary = { padding: "11px 22px", borderRadius: 9, border: "none", cursor: "pointer", background: "#B71C1C", color: "#fff", fontSize: 14, fontWeight: 700, transition: "all 0.15s", boxShadow: "0 2px 8px rgba(183,28,28,0.25)" };
const btnOutline = { padding: "8px 16px", borderRadius: 7, border: "1px solid #E0E0E0", background: "transparent", color: "#757575", cursor: "pointer", fontSize: 12, fontWeight: 500, transition: "all 0.15s" };